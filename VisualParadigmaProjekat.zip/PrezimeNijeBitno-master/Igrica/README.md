# Bowling-Game-PC
A simple bowling game I made using Unity 3D 4.6f and Visual Studio.

** It was really fun working on this project at the same time stressful
** especially trying to figure out how to implement certain functionalities
** with code. 

A few things to note before trying out the game:
-----------------------------------------------------------------------------------------
1. I've have been able to send variables to other classes but have not
   been able to receive variable values from other classes (even with get set functions)
    
   Thus trying to reset all pins at the same time after each frame has been a challenge.

2. At the moment the game can only allow the player to throw the ball countless times
   and each pin is reset immediately it collides with the plane just below the floor.

3. "Options" scene has not been setup to allow for addition of players. 

All in all it was an AMAZING CHALLENGE (Scratched my head a lot!), Hope to finish the game fully and add
different levels and functionalities to it. (^_^)

#Cheers

<p>
    <a href="#">
    <img class=" wp-image-2403 alignleft" width="800" height="621" alt="Capture" src="https://raw.githubusercontent.com/malcolmmaima/Bowling-Game-PC/master/Assets/Screenshot.JPG"></img>

</a>



</p>
    
